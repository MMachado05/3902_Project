public enum StateId
{
    Idle,
    Moving,
    Attacking,
    // will add more here for Chase
}